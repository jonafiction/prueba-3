exports.handler = async (event) => {
  const AWS = require("aws-sdk");
  const sns = new AWS.SNS();

  try {
    // Procesar cada mensaje de SQS
    for (const record of event.Records) {
      const message = JSON.parse(record.body);

      // Publicar en SNS
      await sns
        .publish({
          TopicArn: process.env.SNS_TOPIC_ARN,
          Message: JSON.stringify({
            originalMessage: message,
            processedTime: new Date().toISOString(),
          }),
        })
        .promise();
    }

    return {
      statusCode: 200,
      body: JSON.stringify("Procesamiento exitoso"),
    };
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
};
